<?php
/*
$xsuite_FS_site="F:\\XrchiveStudios\\Projects\\xsuite\\";
$page_file="about.html";
$page_file=$xsuite_FS_site."pages\\".$page_file;

echo $page_file;
echo "<br/>";
*/
phpinfo();
?>