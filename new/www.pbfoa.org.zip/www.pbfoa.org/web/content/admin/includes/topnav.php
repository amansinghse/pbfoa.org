<ul class="shortcut-buttons-set">
				
				<!-- <li><a class="shortcut-button" href="admin.php?mod=addMenu"><span>
					<img src="resources/images/icons/pencil_48.png" alt="icon" /><br />
					Insert Menu Item
				</span></a></li> -->
				
				<li><a class="shortcut-button" href="admin.php?mod=addPage"><span>
					<img src="resources/images/icons/paper_content_pencil_48.png" alt="icon" /><br />
					New Page
				</span></a></li>
				
				<li><a class="shortcut-button" href="admin.php?mod=uploadImage"><span>
					<img src="resources/images/icons/image_add_48.png" alt="icon" /><br />
					Upload  Images
				</span></a></li>
				
				<li><a class="shortcut-button" href="#" onclick="javascript:alert('This Function is Disabled')"><span>
					<img src="resources/images/icons/clock_48.png" alt="icon" /><br />
					Add an Event
				</span></a></li>
				
			 <li><a class="shortcut-button" href="#messages" rel="modal"><span>
					<img src="resources/images/icons/comment_48.png" alt="icon" /><br />
					Messages
				</span></a></li> 
				
			</ul><!-- End .shortcut-buttons-set -->