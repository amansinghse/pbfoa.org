<!-- Page Head -->
<h2>Welcome <?php echo $_SESSION['xsuite_admin_name']."!"; ?> </h2>
<!-- <p id="page-intro">What would you like to do?</p> -->