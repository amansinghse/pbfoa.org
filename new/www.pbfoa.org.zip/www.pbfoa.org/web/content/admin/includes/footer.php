<div id="footer">
<small> <!-- Remove this notice or replace it with whatever you want -->
&#169; Copyright 2016 CMS| Powered by <a href="http://www.pixector.com">Pixector</a> | <a href="#">Top</a>
</small>
</div>
<!-- End #footer -->